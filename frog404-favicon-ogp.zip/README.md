# ファビコンとOGP画像（frog404.work）

`static/` の中身を Zola サイトの `static/` に置く。

| ファイル | 用途 |
|---|---|
| favicon.ico | 16 / 32 / 48px。16pxは手打ちのドット文字（「404」が潰れないように描き分け） |
| favicon.svg | 元データ。文字はアウトライン化済み（IBM Plex Mono SemiBold） |
| apple-touch-icon.png | 180px。iOSのホーム画面 |
| icon-192.png / icon-512.png | Webアプリのマニフェスト用（使う場合のみ） |
| ogp.png | サイト共通のOGP（1200×630） |

## head に書くタグ

```html
<link rel="icon" href="/favicon.ico" sizes="16x16 32x32 48x48">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">

<meta property="og:type" content="website">
<meta property="og:site_name" content="frogworks404">
<meta property="og:image" content="https://frog404.work/ogp.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
```

- `favicon.svg` は head に書かない。SVGを指定すると、対応ブラウザは16pxのタブでもSVGを縮小して使うため、手打ちの16px版が表示されなくなる。
- `og:title` と `og:url` はページごとにテンプレートで出す。
